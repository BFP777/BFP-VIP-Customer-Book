BHAJAN FASHION POINT – VIP Customer Book (Android Studio Project)

यह Android WebView ऐप प्रोजेक्ट है। ऐप HTML को फोन के अंदर चलाता है और ग्राहक डेटा WebView के local storage में रखता है।

APK बनाने के चरण:
1. कंप्यूटर पर Android Studio (Hedgehog या नया) इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Extract किया हुआ BFP_VIP_Customer_Book_Android फोल्डर खोलें।
4. Gradle Sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा।
7. APK फोन में भेजकर इंस्टॉल करें। फोन में “Install unknown apps” की अनुमति माँगी जा सकती है।

महत्वपूर्ण:
- ग्राहक डेटा इसी ऐप के निजी WebView storage में रहता है।
- ऐप uninstall या app data clear करने पर डेटा मिट सकता है। HTML ऐप में मौजूद Backup बटन से JSON बैकअप रखें।
- कॉल के लिए फोन का dialer खुलेगा; कॉल करने से पहले आप नंबर देख सकते हैं।
- WhatsApp लिंक WhatsApp ऐप/वेब में खुलेगा।
- जन्मदिन रिमाइंडर फिलहाल ऐप खोलने पर दिखता है; बैकग्राउंड push notification नहीं है।


मोबाइल से APK बनाने का आसान तरीका (GitHub Actions):
1. ZIP को फोन में डाउनलोड करके Extract करें।
2. github.com पर अकाउंट बनाकर New repository बनाएँ (Public या Private)।
3. Extract किए गए प्रोजेक्ट की सभी फाइलें repository में Upload files से अपलोड करके Commit करें। .github फोल्डर भी अपलोड होना चाहिए।
4. Repository में Actions टैब खोलें। “Build BFP VIP Customer Book APK” workflow चुनें और Run workflow दबाएँ।
5. Build पूरा होने पर नीचे Artifacts में BFP-VIP-Customer-Book-APK डाउनलोड करें। ZIP खोलकर app-debug.apk निकालें और फोन में इंस्टॉल करें।
6. पहली बार GitHub Actions चालू करने की अनुमति/Terms स्वीकार करनी पड़ सकती है।
